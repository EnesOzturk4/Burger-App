﻿namespace ANK15hamburgeruygulama
{
    partial class SiparisBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTümSiparisler = new System.Windows.Forms.Label();
            this.lbxtumSiparisler = new System.Windows.Forms.ListBox();
            this.lblCiro = new System.Windows.Forms.Label();
            this.lblToplamSiparis = new System.Windows.Forms.Label();
            this.lblEkstraMalzeme = new System.Windows.Forms.Label();
            this.lblSatılanUrun = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblSiparişSayısı = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblekstraMalzemeGeliri = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblSatılanUrunAdedi = new System.Windows.Forms.Label();
            this.lblcirooo = new System.Windows.Forms.Label();
            this.lblcirog = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTümSiparisler
            // 
            this.lblTümSiparisler.AutoSize = true;
            this.lblTümSiparisler.Location = new System.Drawing.Point(12, 9);
            this.lblTümSiparisler.Name = "lblTümSiparisler";
            this.lblTümSiparisler.Size = new System.Drawing.Size(97, 13);
            this.lblTümSiparisler.TabIndex = 0;
            this.lblTümSiparisler.Text = "TÜM SİPARİŞLER";
            // 
            // lbxtumSiparisler
            // 
            this.lbxtumSiparisler.FormattingEnabled = true;
            this.lbxtumSiparisler.Location = new System.Drawing.Point(15, 48);
            this.lbxtumSiparisler.Name = "lbxtumSiparisler";
            this.lbxtumSiparisler.Size = new System.Drawing.Size(132, 186);
            this.lbxtumSiparisler.TabIndex = 1;
            // 
            // lblCiro
            // 
            this.lblCiro.AutoSize = true;
            this.lblCiro.Location = new System.Drawing.Point(226, 28);
            this.lblCiro.Name = "lblCiro";
            this.lblCiro.Size = new System.Drawing.Size(34, 13);
            this.lblCiro.TabIndex = 2;
            this.lblCiro.Text = "Ciro : ";
            // 
            // lblToplamSiparis
            // 
            this.lblToplamSiparis.AutoSize = true;
            this.lblToplamSiparis.Location = new System.Drawing.Point(6, 31);
            this.lblToplamSiparis.Name = "lblToplamSiparis";
            this.lblToplamSiparis.Size = new System.Drawing.Size(109, 26);
            this.lblToplamSiparis.TabIndex = 3;
            this.lblToplamSiparis.Text = "Toplam Sipariş Sayısı \r\n\r\n";
            // 
            // lblEkstraMalzeme
            // 
            this.lblEkstraMalzeme.Location = new System.Drawing.Point(31, 39);
            this.lblEkstraMalzeme.Name = "lblEkstraMalzeme";
            this.lblEkstraMalzeme.Size = new System.Drawing.Size(107, 29);
            this.lblEkstraMalzeme.TabIndex = 4;
            this.lblEkstraMalzeme.Text = "Ekstra Malzeme Geliri :\r\n";
            this.lblEkstraMalzeme.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblSatılanUrun
            // 
            this.lblSatılanUrun.AutoSize = true;
            this.lblSatılanUrun.Location = new System.Drawing.Point(34, 16);
            this.lblSatılanUrun.Name = "lblSatılanUrun";
            this.lblSatılanUrun.Size = new System.Drawing.Size(95, 26);
            this.lblSatılanUrun.TabIndex = 5;
            this.lblSatılanUrun.Text = "Satılan Ürün Adedi\r\n \r\n";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblSiparişSayısı);
            this.groupBox2.Controls.Add(this.lblToplamSiparis);
            this.groupBox2.Location = new System.Drawing.Point(220, 78);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(176, 67);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // lblSiparişSayısı
            // 
            this.lblSiparişSayısı.AutoSize = true;
            this.lblSiparişSayısı.Location = new System.Drawing.Point(44, 44);
            this.lblSiparişSayısı.Name = "lblSiparişSayısı";
            this.lblSiparişSayısı.Size = new System.Drawing.Size(13, 13);
            this.lblSiparişSayısı.TabIndex = 4;
            this.lblSiparişSayısı.Text = "0";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblekstraMalzemeGeliri);
            this.groupBox3.Controls.Add(this.lblEkstraMalzeme);
            this.groupBox3.Location = new System.Drawing.Point(220, 166);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(190, 83);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // lblekstraMalzemeGeliri
            // 
            this.lblekstraMalzemeGeliri.AutoSize = true;
            this.lblekstraMalzemeGeliri.Location = new System.Drawing.Point(144, 39);
            this.lblekstraMalzemeGeliri.Name = "lblekstraMalzemeGeliri";
            this.lblekstraMalzemeGeliri.Size = new System.Drawing.Size(13, 13);
            this.lblekstraMalzemeGeliri.TabIndex = 9;
            this.lblekstraMalzemeGeliri.Text = "0";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblSatılanUrunAdedi);
            this.groupBox4.Controls.Add(this.lblSatılanUrun);
            this.groupBox4.Location = new System.Drawing.Point(217, 264);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(179, 71);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            // 
            // lblSatılanUrunAdedi
            // 
            this.lblSatılanUrunAdedi.AutoSize = true;
            this.lblSatılanUrunAdedi.Location = new System.Drawing.Point(69, 42);
            this.lblSatılanUrunAdedi.Name = "lblSatılanUrunAdedi";
            this.lblSatılanUrunAdedi.Size = new System.Drawing.Size(13, 13);
            this.lblSatılanUrunAdedi.TabIndex = 9;
            this.lblSatılanUrunAdedi.Text = "0";
            // 
            // lblcirooo
            // 
            this.lblcirooo.AutoSize = true;
            this.lblcirooo.Location = new System.Drawing.Point(266, 28);
            this.lblcirooo.Name = "lblcirooo";
            this.lblcirooo.Size = new System.Drawing.Size(0, 13);
            this.lblcirooo.TabIndex = 8;
            // 
            // lblcirog
            // 
            this.lblcirog.AutoSize = true;
            this.lblcirog.Location = new System.Drawing.Point(272, 28);
            this.lblcirog.Name = "lblcirog";
            this.lblcirog.Size = new System.Drawing.Size(0, 13);
            this.lblcirog.TabIndex = 9;
            // 
            // SiparisBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblcirog);
            this.Controls.Add(this.lblcirooo);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.lblCiro);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lbxtumSiparisler);
            this.Controls.Add(this.lblTümSiparisler);
            this.Name = "SiparisBilgileri";
            this.Text = "SiparisBilgileri";
            this.Load += new System.EventHandler(this.SiparisBilgileri_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTümSiparisler;
        private System.Windows.Forms.ListBox lbxtumSiparisler;
        private System.Windows.Forms.Label lblCiro;
        private System.Windows.Forms.Label lblToplamSiparis;
        private System.Windows.Forms.Label lblEkstraMalzeme;
        private System.Windows.Forms.Label lblSatılanUrun;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblSiparişSayısı;
        private System.Windows.Forms.Label lblekstraMalzemeGeliri;
        private System.Windows.Forms.Label lblSatılanUrunAdedi;
        private System.Windows.Forms.Label lblcirooo;
        private System.Windows.Forms.Label lblcirog;
    }
}